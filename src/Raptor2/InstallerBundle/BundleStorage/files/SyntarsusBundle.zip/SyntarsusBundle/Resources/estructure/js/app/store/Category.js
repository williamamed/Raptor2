Ext.define('GestEstructure.store.Category', {
    extend: 'Ext.data.Store',
    model: 'GestEstructure.model.CategoryModel',
    autoLoad: true
});