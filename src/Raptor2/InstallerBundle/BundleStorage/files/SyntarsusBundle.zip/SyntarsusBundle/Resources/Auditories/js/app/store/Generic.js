Ext.define('Auditories.store.Generic', {
    extend: 'Ext.data.Store',
    model: 'Auditories.model.GenericModel'
});