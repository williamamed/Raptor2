Ext.define('GestRol.store.Rol', {
    extend: 'Ext.data.Store',
    model: 'GestRol.model.RolModel',
    autoLoad: true
});