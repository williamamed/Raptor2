Ext.define('Auditories.store.Estadistic', {
    extend: 'Ext.data.Store',
    model: 'Auditories.model.EstadisticModel'
});