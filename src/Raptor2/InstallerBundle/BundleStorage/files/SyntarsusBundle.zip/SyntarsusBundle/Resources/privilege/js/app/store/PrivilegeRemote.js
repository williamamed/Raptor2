Ext.define('GestPrivilege.store.PrivilegeRemote', {
    extend: 'Ext.data.Store',
    model: 'GestPrivilege.model.PrivilegeRemoteModel'
    
});