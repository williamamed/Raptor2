<?php
/**
 * Generated with RAPTOR NEMESIS
 * You can add a route prefix to this Controller
 * puting a @Route annotation to this class.
 */

namespace Raptor2\SyntarsusBundle\Controller;

use Raptor\Bundle\Controller\Controller;

/**
 * @Route
 */
class DefaultController extends Controller{
    
    /**
     * Add your definition route and the name route[optional]
     *
     * @Route /test
     * @RouteName 
     * 
     * @param \Slim\Http\Request $request
     * @param \Slim\Http\Response $response
     * @param \Slim\Route $route
     */
    public function indexAction($request,$response,$route) {
        return $this->render('');
    }
    
    
}

?>
