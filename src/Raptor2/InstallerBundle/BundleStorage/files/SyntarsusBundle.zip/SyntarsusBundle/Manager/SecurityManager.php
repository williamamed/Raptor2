<?php

/**
 * Raptor - Integration PHP 5 framework
 *
 * @author      William Amed <watamayo90@gmail.com>, Otto Haus <ottohaus@gmail.com>
 * @copyright   2014 
 * @link        http://dinobyte.net
 * @version     2.0.1
 * @package     Raptor
 *
 * MIT LICENSE
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
namespace Raptor2\SyntarsusBundle\Manager;
/**
 * SecurityManager handle the Identification-Autentication, 
 * Authorization and Auditories Process
 *
 * 
 */
class SecurityManager extends \Raptor\Security\AbstractSecurityManager implements \Raptor\Bundle\Route\Rule{
    /**
     *
     * @var \Raptor\Raptor
     */
    private $app;
    /**
     * This is the user indentificated in the indentification process
     * @var \Raptor2\SyntarsusBundle\Model\Entity\SecurityUser
     */
    private $user;
    /**
     * the username gived by the user in the form login
     * @var string
     */
    private $username;
    /**
     *the password gived by the user in the form login
     * @var string
     */
    private $password;
    /**
     * Redirect when user authenticate
     * @var boolean
     */
    private $redirect;
    /**
     * This is the error message after any event
     * @var string
     */
    private $errorMessage;


    /**
     * This is the entry of Security Manager Routing, calling the 4 main process
     * @param \Raptor\Raptor $app
     * @return boolean
     */
    public function call(\Raptor\Raptor $app) {
        $this->redirect=true;
        $this->app=$app;
        $opt=$this->app->getConfigurationLoader()->getOptions();
        if(isset($opt['options']['syntarsus']) and isset($opt['options']['syntarsus']['auth']) and $opt['options']['syntarsus']['auth']==='saml')
            return $this->samlHandler ();
        
        if(!$app->getSecurity()->isAuthenticated()){
            $app->getLanguage()->setCurrentBundle('\Raptor2\SyntarsusBundle\SyntarsusBundle');
            $this->handleAuthenticationRequest();
            
            $app->response()->write($app->render('@SyntarsusBundle/Login/index.html.twig',array(
                'error'=>  $this->errorMessage,
                'username'=>$this->app->request()->post('username')
            )));
            $app->contentType('text/html; charset=UTF-8');
            return true;
        }else{
            
            return $this->authorization();
        }
        
    }
    
    public function setRedirect($redirect) {
        $this->redirect=$redirect;
    }
    /**
     * 
     * @param \Raptor\Raptor $app
     */
    public function handleAuthenticationRequest() {
        /**
         * Check first its has a remember me cookie
         * and login with hem
         */
        if ($this->handleSyntarsusCookie()) {
            $this->authentication();
        }
        if($this->app->request()->isFormData() and !$this->app->request()->isXhr()){
            if($this->app->request()->post('username') and $this->app->request()->post('password')){
                $this->username=$this->app->request()->post('username');
                $this->password=$this->app->request()->post('password');
                $remember=$this->app->request()->post('remember');
                
                /**
                 * if not has a remember cookie continue with the login routine process
                 */
                if($this->indentification()){
                    $this->setRememberMe($this->username, $this->password, $remember);
                    $this->authentication();
                }else{
                    $this->errorMessage= $this->app->getLanguage()->getBundleLanguage('wrong_user_pass');
                }
            }else{
                $this->errorMessage=  $this->app->getLanguage()->getBundleLanguage('wrong_user_pass');
            }
        }
    }
    
    /**
     * Invoke the indentification process
     * 
     * 
     * @param \Raptor\Raptor $app
     */
    public function indentification() {
        $indenficated=$this->app->getStore()
                ->getManager()
                ->getRepository('SyntarsusBundle:SecurityUser')
                ->findOneBy(array(
                    'username'=> $this->username,
                    'state'=>true
                ));
         $this->user=$indenficated;
       return ($indenficated)?true:false;
    }
    
    /**
     * Invoke the authentication process
     * 
     * YOU NEED TO LOCK THE ACCESS FOR N ATTEMPS
     * OF LOGIN BY A CERTAIN TIME
     * 
     * TODO register the atemmpt failed of login when
     * the user pass the N Attempts
     * 
     * @return boolean
     */
    public function authentication() {
       $user=  $this->user;
       $pass= $this->password;
       if($user->getAttempts()!==NULL){
           if($user->getAttempts()<\Raptor2\SyntarsusBundle\SyntarsusBundle::ATTEMPTS){
                $user->setAttempts($user->getAttempts()+1);
           }else{
               $current=new \DateTime();
               if($user->getLastattempt()->getTimestamp()+\Raptor2\SyntarsusBundle\SyntarsusBundle::LOCKTIME<$current->getTimestamp()){
                   $user->setAttempts(1);
               }else{
                   $this->errorMessage=$this->app->getLanguage()->getBundleLanguage('lock_user');
                   $name=$user->getUsername();
                   $attempt=\Raptor2\SyntarsusBundle\SyntarsusBundle::ATTEMPTS;
                   $min=\Raptor2\SyntarsusBundle\SyntarsusBundle::LOCKTIME/60;
                   $this->app->getLog()->alert(
                           "The user $name was blocked for $min minutes, posible identity supplantation after $attempt attempts of login."
                           );
                   return false;
               }
           }
       }else{
           $user->setAttempts(1);
       }
       $user->setLastattempt(new \DateTime());
       
       $valid=\Raptor\Security\SecureHash::verify( $pass, $user->getPassword());
       
       if($valid){
                $user->setAttempts(0);
                $this->app->getStore()->getManager()->persist($user);
                $this->app->getStore()->getManager()->flush();
                $this->app->getSecurity()->setAuthenticated(true);
                $this->app->getSecurity()->setUser(array(
                        'username'=>$user->getUsername(),
                        'rol'=>$user->getIdRol()->getName()
                ));
                $this->app->getSession()->regenerateId();
                if($this->redirect){
                    $this->app->redirect($this->app->request()->getPath());
                }else
                    return $valid;
       }
       $this->errorMessage=$this->app->getLanguage()->getBundleLanguage('wrong_user_pass');
       $this->app->getStore()->getManager()->persist($user);
       $this->app->getStore()->getManager()->flush();     
       return $valid;
        
    }
    /**
     * Invoke the authorization process
     * @return boolean
     */
    public function authorization() {
        $session=  $this->app->getSecurity()->getUser();
        $matchedRoutes = $this->app->router()->getMatchedRoutes($this->app->request()->getMethod(), $this->app->request()->getResourceUri());
        $routes= array();   
        foreach ($matchedRoutes as $route) {
             $routes[] = $route->getPattern();
        }
        $privileges=$this->app->getStore()
                ->getManager()
                ->getRepository('SyntarsusBundle:SecurityUser')
                ->checkRoute($session['username'],$routes);
        $current=$this->app->request()->getResourceUri();
        foreach ($privileges as $priv) {
                $aprobed=new \Raptor\Util\ItemList($this->app->getStore()
                    ->getManager()
                    ->getRepository('SyntarsusBundle:SecurityUser')
                    ->getPrivilegesUserPerRoute($session['username'],$priv->getId()));
                
                $this->app->setViewPlugin('core_library_inside',$this->app->render('@SyntarsusBundle/SecurityManager/plugin/core.js.twig',array(
                    'privileges'=>$aprobed
                )));
                $this->app->getLog()->info(
                    "Accesing route $current."
                );
                return FALSE;
        }
        
        $this->app->getLog()->alert(
           "Blocking the access for route $current for not sufficient privileges."
              );
        if($this->app->request()->isAjax()){
            $listMsg=new \Raptor\Util\ItemList();
            $listMsg->set('msg','ACCESS DENIED');
            $listMsg->set('cod',  \Raptor\Bundle\Controller\Controller::ERROR);
            $listMsg->set('success', true);
            $this->app->response()->write($listMsg->toJson());
            $this->app->contentType(\Raptor\Raptor::JSON);
        }else
            $this->app->response()->write($this->app->render('@SyntarsusBundle/SecurityManager/denied.html.twig'));
        return true;
    }
    
    /**
     * Register the auditory handler for trace the user actions
     */
    public function auditory() {
        $this->app->getLog()->setEnabled(true);
        $this->app->getLog()->setWriter(new Log\LogWriter($this->app));
    }
    
    /**
     * Set the rememberme cookie if the user check it
     * @param string $user
     * @param string $pass
     * @param string $remember
     */
    private function setRememberMe($user,$pass,$remember) {
        if($remember){
            $token=array('username'=>$user,'password'=>$pass);
            
            $this->app->setCookie("SyntarsusLoginToken",  json_encode($token),strtotime('+1 year'),NULL, NULL, NULL, false, true);
        }
    }
    
    /**
     * Handle the remember me cookie if exist in the user request
     * @param \Raptor2\SyntarsusBundle\Model\Entity\SecurityUser $user
     * @param string $passwordCookie
     * @return boolean
     */
    private function handleSyntarsusCookie() {
        
        $cookie=$this->app->getCookie("SyntarsusLoginToken", true, true);
        
        if ($cookie !== NULL) {
            $token = json_decode($cookie, true);
            $indenficated = $this->app->getStore()
                    ->getManager()
                    ->getRepository('SyntarsusBundle:SecurityUser')
                    ->findOneBy(array(
                'username' => $token['username'],
                'state' => true
            ));
            $this->user = $indenficated;
            $this->password=$token['password'];
           
            return ($indenficated)?true:false;
        }
        
        
        return false;
    }
    
    /**
     * Handle the identification process by SAML
     * @return boolean
     */
    public function samlHandler() {
        
        if (!$this->app->getSecurity()->isAuthenticated()){
            $options = $this->app->getConfigurationLoader()->getOptions();
            $secret = '';
            if (isset($options['raptor']) and isset($options['raptor']['secret']))
                $secret = $options['raptor']['secret'];
            $new = session_id();
            $this->app->getSession()->set('rpt_csrf', md5($secret . $new));
            $token=$this->app->getSecurity()->getToken();
            $id=  session_id();
            $this->app->redirect($this->app->request()->getRootUri().'/../SSO/index.php?tk='.$token.'&ref='.$id.'&samlroute='.$this->app->request()->getResourceUri());
        }else{
           
          return $this->authorization();
        }
        
    }
    
    
    /**
     * Set the app for this security manager
     * @param \Raptor\Raptor $app
     */
    public function setApp($app) {
        $this->app=$app;
    }
    /**
     * Mark the user session has authenticated
     */
    public function login() {
        $this->app->getSecurity()->login();
    }
    
    /**
     * Mark the user session has non-authenticated
     */
    public function logout() {
        $this->app->getSecurity()->logout();
        $this->app->deleteCookie("SyntarsusLoginToken");
    }
    
    public function setUsername($username) {
        $this->username = $username;
    }

    public function setPassword($password) {
        $this->password = $password;
    }


}

?>
